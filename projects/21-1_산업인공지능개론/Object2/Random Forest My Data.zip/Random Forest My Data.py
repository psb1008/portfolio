import pandas as pd
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics


df = pd.read_csv('dataset.csv')
data = pd.DataFrame(df)
x = data[data.columns.difference(['Type'])]
y = data['Type']
print(data)
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.3)
print("No. of training data: ", len(x_train))
print("No. of test data:", len(y_test))

forest = RandomForestClassifier(n_estimators=100)
forest.fit(x_train, y_train)

y_pred = forest.predict(x_test)
print('Accuracy:', metrics.accuracy_score(y_test, y_pred))

#print(data)

#colums = [0 for i in range(28*28)]
#count = 0
#for y in range(0, 28):
#    for x in range(0, 28):
#        c = "(" + str(y) + "_" + str(x) + ")" 
#        colums[count] = c
#        count += 1
#print(df)
#x = colums
#y = data['Type']